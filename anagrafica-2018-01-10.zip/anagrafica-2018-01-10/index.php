<?php
session_start();

    require_once("__init__.php");
    require_once("header.php");

    require_once("footer.php");
