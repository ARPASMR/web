<?php

    require_once("../__init__.php");
    require_once("libs.allineamento.php");